const main = {
  apiKey: 'AIzaSyBLh2F-CWB5PBm3iTg8myatGcAhbbLTmFs',
  authDomain: 'forestry-learning-modules.firebaseapp.com',
  databaseURL: 'https://forestry-learning-modules.firebaseio.com',
  projectId: 'forestry-learning-modules',
  storageBucket: 'forestry-learning-modules.appspot.com',
  messagingSenderId: '911056773107'
};

const configs = {
  main
};

export {
  configs
};

// dev
